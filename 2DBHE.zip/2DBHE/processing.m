function [image] = processing(image, LR_LPs,LR_LPc,LR_RPs,LR_RPc,UD_UPs,UD_UPc,UD_DPs,UD_DPc,message_L,message_R,message_U,message_D,D_U,D_D,D_L,D_R,L_R)%D_U,D_D,D_L,D_Rָ����
    image_size = size(image);
    if L_R == 0 
        %Combine UD_UPc with its neighbor   para = UD_UPc , D_U , UD_UPs
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if D_U == -1  %ps>pc
                    if image(i, j) == UD_UPc-D_U-1
                        image(i, j) = image(i, j) + D_U;
                    end
                else %ps<pc
                    if image(i, j) == UD_UPc-D_U-1
                        image(i, j) = image(i, j) + D_U;
                    end
                end    
            end
        end
        %Shift UD_UPs neighbors towards UD_UPc
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if D_U == -1
                    if image(i, j) > UD_UPc-1 && image(i, j) < UD_UPs-1
                        image(i, j) = image(i, j) + D_U;
                    end
                else
                    if image(i, j) < UD_UPc-1 && image(i, j) > UD_UPs-1
                        image(i, j) = image(i, j) + D_U;
                    end
                end
            end
        end
        %Embed
        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if length(message_U) <temp
                    continue;
                else
                    if image(i,j) == UD_UPs - 1
                        if message_U(temp) == 0
                            temp = temp + 1;
                        else 
                            image(i, j) = image(i, j) + D_U;
                            temp = temp + 1;
                        end
                    end
                end
            end
        end
        %��������������������������������������������������������������������
        %Combine UD_DPc with its neighbor   para = UD_DPc , D_D  ,UD_DPs
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if D_D == -1
                    if image(i, j) == UD_UPc-D_D-1
                        image(i, j) = image(i, j) + D_D;
                    end
                else 
                    if image(i, j) == UD_UPc-D_D-1
                        image(i, j) = image(i, j) + D_D;
                    end
                end    
            end
        end
        %Shift UD_DPs neighbors towards UD_DPc
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if D_D == -1
                    if image(i, j) > UD_DPc-1 && image(i, j) < UD_DPs-1
                        image(i, j) = image(i, j) + D_D;
                    end
                else
                    if image(i, j) < UD_DPc-1 && image(i, j) > UD_DPs-1
                        image(i, j) = image(i, j) + D_D;
                    end
                end
            end
        end

        temp1 = 1;
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)-1
                if length(message_D) <temp1
                    continue;
                else
                    if image(i,j) == UD_DPs - 1
                        if message_D(temp1) == 0
                            temp1 = temp1 + 1;
                        else 
                            image(i, j) = image(i, j) + D_D;
                            temp1 = temp1 + 1;
                        end
                    end
                end
            end
        end
        %��������������������������������������������������������������������
    else 
        %Combine LR_LPc with its neighbor
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if image(i, j) == LR_LPc-D_L-1
                    image(i, j) = image(i, j) + D_L;
                end
            end
        end
        %Shift LR_LPs neighbors towards LR_LPc
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if D_L == 1
                    if image(i, j) > LR_LPs-1 && image(i, j) < LR_LPc-1
                        image(i, j) = image(i, j) + D_L;
                    end
                else
                    if image(i, j) < LR_LPs-1 && image(i, j) > LR_LPc-1
                        image(i, j) = image(i, j) + D_L;
                    end
                end
            end
        end
        %Embed
        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if length(message_L)<temp
                    continue;
                else
                    if image(i,j) == LR_LPs - 1
                        if message_L(temp) == 0
                            temp = temp + 1;
                        else 
                            image(i, j) = image(i, j) + D_L;
                            temp = temp + 1;
                        end
                    end
                end
            end
        end
        %�������������������������������������������������������������������� 
       %Combine LR_RPc with its neighbor
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if image(i, j) == LR_RPc-D_R-1
                    image(i, j) = image(i, j) + D_R;
                end
            end
        end
        %Shift LR_RPs neighbors towards LR_RPc
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if D_R == 1
                    if image(i, j) > LR_RPs-1 && image(i, j) < LR_RPc-1
                        image(i, j) = image(i, j) + D_R;
                    end
                else
                    if image(i, j) < LR_RPs-1 && image(i, j) > LR_RPc-1
                        image(i, j) = image(i, j) + D_R;
                    end
                end
            end
        end
        %Embed
        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 1 : image_size(2)
                if length(message_R) < temp
                    continue;
                else
                    if image(i,j) == LR_RPs - 1
                        if message_R(temp) == 0
                            temp = temp + 1;
                        else 
                            image(i, j) = image(i, j) + D_R;
                            temp = temp + 1;
                        end
                    end
                end
            end
        end
    end
    
end

