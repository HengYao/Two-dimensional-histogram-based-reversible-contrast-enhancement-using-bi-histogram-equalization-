function [image] = last_process(image, LR_LPs,LR_LPc,LR_RPs,LR_RPc,UD_UPs,UD_UPc,UD_DPs,UD_DPc,message_L,message_R,message_U,message_D,D_U,D_D,D_L,D_R,L_R)
    image_size = size(image);
    if L_R == 0
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 1
                    continue;
                else
                    if image(i, j) == UD_UPc+D_U-1
                        image(i, j) = image(i, j) - D_U;
                    end
                end
            end
        end
        %Shift Ps_i neighbors towards Pc_i
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 1
                    continue;
                else
                    if D_U == 1
                        if image(i, j) > UD_UPc-1 && image(i, j) < UD_UPs-1
                            image(i, j) = image(i, j) - D_U;
                        end
                    else
                        if image(i, j) < UD_UPc-1 && image(i, j) > UD_UPs-1
                            image(i, j) = image(i, j) - D_U;
                        end
                    end
                end
            end
        end
        %Embed Ps_i
        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if length(message_U) < temp
                    continue;
                else
                    if i == 1 && j <= 17 && j >= 0
                        continue;
                    else
                        if image(i,j) == UD_UPs - 1
                            if message_U(temp) == 0
                                temp = temp + 1;
                            else
                                image(i, j) = image(i, j) - D_U;
                                temp = temp + 1;
                            end
                        end
                    end
                end
            end
        end
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 1
                    continue;
                else
                    if image(i, j) == UD_DPc+D_D-1
                        image(i, j) = image(i, j) - D_D;
                    end
                end
            end
        end

        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 1
                    continue;
                else
                    if D_D == 1
                        if image(i, j) > UD_DPc-1 && image(i, j) < UD_DPs-1
                            image(i, j) = image(i, j) - D_D;
                        end
                    else
                        if image(i, j) < UD_DPc-1 && image(i, j) > UD_DPs-1
                            image(i, j) = image(i, j) - D_D;
                        end
                    end
                end
            end
        end

        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if length(message_D) - temp < 0
                    continue
                else
                    if i == 1 && j <= 17 && j >= 0
                        continue;
                    else
                        if image(i,j) == UD_DPs - 1
                            if message_D(temp) == 0
                                temp = temp + 1;
                            else
                                image(i, j) = image(i, j) - D_D;
                                temp = temp + 1;
                            end
                        end
                    end
                end
            end
        end
    else 

        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 1
                    continue;
                else
                    if image(i, j+1) == LR_LPc-D_L-1
                        image(i, j+1) = image(i, j+1) + D_L;
                    end
                end
            end
        end

        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 1
                    continue;
                else
                    if D_L == 1
                        if image(i, j+1) > LR_LPs-1 && image(i, j+1) < LR_LPc-1
                            image(i, j+1) = image(i, j+1) + D_L;
                        end
                    else
                        if image(i, j+1) < LR_LPs && image(i, j+1) > LR_LPc-1
                            image(i, j+1) = image(i, j+1) + D_L;
                        end
                    end
                end
            end
        end

        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 0
                    continue;
                else
                    if message_L< temp
                        continue
                    else
                        if image(i,j+1) == LR_LPs - 1
                            if message_L(temp) == 0
                                temp = temp + 1;
                            else
                                image(i, j+1) = image(i, j+1) + D_L;
                                temp = temp + 1;
                            end
                        end
                    end
                end
            end
        end

        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 1
                    continue;
                else
                    if image(i, j+1) == LR_RPc-D_R-1
                        image(i, j+1) = image(i, j+1) + D_R;
                    end
                end
            end
        end

        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 1
                    continue;
                else
                    if D_L == 1
                        if image(i, j+1) > LR_RPs-1 && image(i, j+1) < LR_RPc-1
                            image(i, j+1) = image(i, j+1) + D_R;
                        end
                    else
                        if image(i, j+1) < LR_RPs && image(i, j+1) > LR_RPc-1
                            image(i, j+1) = image(i, j+1) + D_R;
                        end
                    end
                end
            end
        end

        temp = 1;
        for i = 1 : image_size(1)
            for j = 1 : 2 : image_size(2)
                if i == 1 && j <= 17 && j >= 0
                    continue;
                else
                    if message_R < temp
                        continue
                    else  
                        if image(i,j+1) == LR_RPs - 1
                            if message_R(temp) == 0
                                temp = temp + 1;
                            else
                                image(i, j+1) = image(i, j+1) + D_R;
                                temp = temp + 1;
                            end
                        end
                    end
                end
            end
        end
    end

end

